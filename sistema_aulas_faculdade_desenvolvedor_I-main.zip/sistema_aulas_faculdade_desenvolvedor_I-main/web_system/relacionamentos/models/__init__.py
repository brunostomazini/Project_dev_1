from .base_model import *
from .person import *
from .reporter import *
from .magazine import *
from .article import *
