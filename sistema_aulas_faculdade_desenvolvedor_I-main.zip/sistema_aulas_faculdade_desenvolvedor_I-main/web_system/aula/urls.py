from operator import index
from django.conf.urls import include
from django.contrib import admin
from django.urls import path
import aula.views.estatisticas as views_funcoes
from aula.views import PrimeiraView
from aula.views import NomeView
from aula.views import *

from aula.views import saudacaoView

app_name = 'aula'




urlpatterns = [
    path('funcao/teste', views_funcoes.primeira_view, name="primeira_view"),

    path('funcao/saudacao', views_funcoes.saudacao, name="saudacao"),

    path('funcao/teste/<str:name>', views_funcoes.teste, name="teste"),

    path('classe/teste', PrimeiraView.as_view(), name='primeira_view_classe'),

    path('classe/saudacao', saudacaoView.as_view(), name='saudacao_view_classe'),

    path('classe/nome_classe/<str:cidade>', NomeView.as_view(), name='nome_view_classe'),
]
