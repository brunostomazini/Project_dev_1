from .estatisticas import *
from .primeira import *
from .saudacaoView import *
from .nomeView import  *