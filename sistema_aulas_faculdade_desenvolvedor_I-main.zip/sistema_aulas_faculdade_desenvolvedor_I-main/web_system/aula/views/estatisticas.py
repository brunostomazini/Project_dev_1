from datetime import datetime
from django.shortcuts import HttpResponse
from aula.models import Perfil

def primeira_view(request):
    mensagem = "Bom dia"
    return HttpResponse(mensagem, status=290)
    #return HttpResponse(mensagem, 'primeira.html', {'mensagem': mensagem})


def saudacao(request):
    agora = datetime.now()
    mensagem = "Boa noite"
    if 12 > agora.hour > 6:
        mensagem ="Bom dia"
    elif 0 < agora.hour <= 6:
        mensagem ="Boa Madrugada"


    completo = f"<html><body><h1>{mensagem.capitalize()} Visitante!" \
                f"<br />{agora}<h1><body><html>"

    return HttpResponse(completo)

"""def nome(request, name):
    perfil - Perfil.objects.find_by_name(name)
    objeto = serializers.serialize('python', perfil)
    return  JsonResponse(object, safe=False)"""

def teste(request):
   pass

