from django.shortcuts import HttpResponse
from django.views import View
from ..models import Perfil

class NomeView(View):
    @staticmethod
    def get(request):
        pessoas = Perfil.objects.all()
        mensagem = ""
        for objecst in pessoas:
            mensagem += f"<p>Cidade:{objecst.cidade}<br></p><p>Pais:{objecst.pais}<br></p><hr>"
        return HttpResponse(mensagem)