from datetime import datetime
from django.shortcuts import HttpResponse
from django.views import View


class saudacaoView(View):
    @staticmethod
    def get(self, request):
        agora = datetime.now()
        mensagem = "bom noite!"
        if 12 > agora.hour >6:
            mensagem = "bom dia!"

        elif 0 < agora.hour <=6:
            mensagem = "boa madrugada!"


        completo = f'<html><body><h1>{mensagem.capitalize()}<h1><body><html>'

        return HttpResponse(completo)