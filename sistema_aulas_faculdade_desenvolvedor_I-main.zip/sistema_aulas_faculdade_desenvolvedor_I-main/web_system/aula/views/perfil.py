from gc import get_objects

from aula.models import Perfil
from django.shortcuts import render, redirect, get_objects_or_404


def perfil_list(request):
    perfils = Perfil.objects.all()

    context = {
        'perfils': perfils
    }

    return render(request, 'perfils/list.html', context)

def perfil_detail(request, pk):
    perfil = Perfil.objects.get(id=pk)
    context = {
        'perfil' : perfil
    }

    return render(request, 'perfils/read.html', context)

def perfil_delete(request, perfil_id):
     perfil = get_objects_or_404(Perfil, pk=perfil_id)

     try:
         if request.method == 'POST':
             v_perfil_id = request.POST.get('perfil_id', None)
             if int(v_perfil_id) == perfil_id:
                 perfil.delete()
                 return redirect('app:perfil_list')
         else:
             context = {
                 'perfil':perfil
             }
             return render(request, 'perfils/delete.html', context)
     except:
        context = {}
        return render(request, "perfils/list.html", context)