from .estaticas import *
from .contatos import *
from .contato_view import *