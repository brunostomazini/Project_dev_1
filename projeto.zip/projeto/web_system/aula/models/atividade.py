from .base import BaseModel
from django.db import models


class Atividade(BaseModel):
    nome = models.CharField('Nome', max_length=100)